if __name__ == "__main__":
    import sys
    import os

    pkg_dir = os.path.split(
        os.path.split(os.path.split(os.path.abspath(__file__))[0])[0]
    )[0]
    parent_dir, pkg_name = os.path.split(pkg_dir)
    is_pygame_pkg = pkg_name == "tests" and os.path.split(parent_dir)[1] == "pygame"
    if not is_pygame_pkg:
        sys.path.insert(0, parent_dir)
else:
    is_pygame_pkg = __name__.startswith("pygame.tests.")

import unittest


class KeyModuleTest(unittest.TestCase):
    pass


if __name__ == "__main__":
    unittest.main()
